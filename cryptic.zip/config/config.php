<?php

$host = "localhost";
$db_name = "cryptic_db";
$username = "monkey";
$password = "Loons123";

//$host = "localhost";
//$db_name = "evenspir_cryptic_db";
//$username = "evenspir_monkey";
//$password = "L00ns123@";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

function loadEnv($file)
{
    if (!file_exists($file)) {
        return;
    }

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        list($key, $value) = explode('=', $line, 2);
        $_ENV[$key] = trim($value);
    }
}

// Load `.env` manually
loadEnv(__DIR__ . '/../.env');

return [
    'smtp_host' => $_ENV['SMTP_HOST'],
    'smtp_user' => $_ENV['SMTP_USER'],
    'smtp_pass' => $_ENV['SMTP_PASS'],
    'smtp_port' => $_ENV['SMTP_PORT']
];


?>
