<?php
session_start();
require '../config/config.php';

// Protect Admin Actions
if (!isset($_SESSION["admin_id"])) {
    header("Location: route_logon");
    exit();
}

// Validate Request
if (!isset($_GET["id"]) || !isset($_GET["action"]) || !isset($_GET["type"])) {
    header("Location: route_dashboard");
    exit();
}

$transactionId = $_GET["id"];
$action = $_GET["action"];
$type = $_GET["type"];  // 'deposit' or 'withdrawal'

$pdo->beginTransaction();  // Start transaction

if ($type === "deposit") {
    // Fetch Pending Deposit
    $stmt = $pdo->prepare("SELECT * FROM crypto_deposits WHERE id = ? AND status = 'pending'");
    $stmt->execute([$transactionId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        header("Location: route_dashboard");
        exit();
    }

    if ($action == "approve") {
        // Approve Deposit & Update User Balance
        $updateStmt = $pdo->prepare("UPDATE crypto_deposits SET status = 'approved', approved_at = NOW(), admin_id = ? WHERE id = ?");
        $updateStmt->execute([$_SESSION["admin_id"], $transactionId]);

        // Insert into `crypto_transactions` (Recording the Deposit)
        $stmt = $pdo->prepare("INSERT INTO crypto_transactions (user_id, crypto_type, transaction_type, amount, wallet_address, status, approved_at, admin_id) 
        VALUES (?, ?, 'deposit', ?, ?, 'approved', NOW(), ?)");
        $stmt->execute([$transaction['user_id'], $transaction['crypto_type'], $transaction['amount'], $transaction['wallet_address'], $_SESSION["admin_id"]]);

        // Update User's Crypto Balance
        $updateBalanceQuery = "UPDATE crypticusers SET {$transaction['crypto_type']}_balance = {$transaction['crypto_type']}_balance + ? WHERE id = ?";
        $updateBalance = $pdo->prepare($updateBalanceQuery);
        $updateBalance->execute([$transaction["amount"], $transaction["user_id"]]);

    } elseif ($action == "reject" && isset($_POST["rejection_reason"])) {
        // Reject Deposit with Reason
        $rejectionReason = $_POST["rejection_reason"];
        $updateStmt = $pdo->prepare("UPDATE crypto_deposits SET status = 'rejected', rejection_reason = ?, approved_at = NOW(), admin_id = ? WHERE id = ?");
        $updateStmt->execute([$rejectionReason, $_SESSION["admin_id"], $transactionId]);

        // Send Rejection Email to User
        sendRejectionEmail($transaction["user_id"], $transaction["crypto_type"], $transaction["amount"], $rejectionReason);
    }
} elseif ($type === "withdrawal") {
    // Fetch Pending Withdrawal
    $stmt = $pdo->prepare("SELECT * FROM crypto_withdrawals WHERE id = ? AND status = 'pending'");
    $stmt->execute([$transactionId]);
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$transaction) {
        header("Location: route_dashboard");
        exit();
    }

    if ($action == "approve") {
        // Approve Withdrawal & Record Transaction
        $insertStmt = $pdo->prepare("
            INSERT INTO crypto_transactions (user_id, crypto_type, transaction_type, amount, wallet_address, status, created_at, admin_id)
            VALUES (?, ?, 'withdrawal', ?, ?, 'approved', NOW(), ?)
        ");
        $insertStmt->execute([
            $transaction["user_id"],
            $transaction["crypto_type"],
            $transaction["amount"],
            $transaction["wallet_address"],
            $_SESSION["admin_id"]
        ]);

        // Deduct from User Balance
        $updateBalance = $pdo->prepare("
            UPDATE crypticusers 
            SET {$transaction['crypto_type']}_balance = {$transaction['crypto_type']}_balance - ?
            WHERE id = ?
        ");
        $updateBalance->execute([
            $transaction["amount"],
            $transaction["user_id"]
        ]);

        // Update Withdrawal Status
        $updateStmt = $pdo->prepare("UPDATE crypto_withdrawals SET status = 'approved', approved_at = NOW(), admin_id = ? WHERE id = ?");
        $updateStmt->execute([$_SESSION["admin_id"], $transactionId]);

    } elseif ($action == "reject" && isset($_POST["rejection_reason"])) {
        // Reject Withdrawal with Reason
        $rejectionReason = $_POST["rejection_reason"];
        $updateStmt = $pdo->prepare("UPDATE crypto_withdrawals SET status = 'rejected', rejection_reason = ?, approved_at = NOW(), admin_id = ? WHERE id = ?");
        $updateStmt->execute([$rejectionReason, $_SESSION["admin_id"], $transactionId]);

        // Send Rejection Email to User
        sendRejectionEmail($transaction["user_id"], $transaction["crypto_type"], $transaction["amount"], $rejectionReason);
    }
}

$pdo->commit();  // Commit transaction


/**
 *  Send Email Notification to User on Rejection
 */
function sendRejectionEmail($userId, $cryptoType, $amount, $reason) {
    global $pdo;

    // Fetch User Email
    $stmt = $pdo->prepare("SELECT email FROM crypticusers WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) return;

    $to = $user["email"];
    $subject = "Your $cryptoType Deposit/Withdrawal Was Rejected";
    $message = "
        <h3>Dear User,</h3>
        <p>Your $cryptoType transaction of <strong>$amount $cryptoType</strong> has been rejected.</p>
        <p><strong>Reason:</strong> $reason</p>
        <p>Please contact support for further assistance.</p>
        <p>Best Regards,<br>Crypto Team</p>
    ";

    // Send Email (Using PHPMailer or mail function)
    mail($to, $subject, $message, "Content-Type: text/html; charset=UTF-8");
}

header("Location: route_dashboard");
exit();
?>