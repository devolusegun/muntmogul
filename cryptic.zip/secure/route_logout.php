<?php
session_start();
session_destroy();
header("Location: route_logon");
exit();
?>
