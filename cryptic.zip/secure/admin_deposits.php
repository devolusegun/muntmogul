<?php
session_start();
require '../config/config.php';

if (!isset($_SESSION["admin_id"])) {
    header("Location: route_logon");
    exit();
}

// ✅ Fetch Pending Deposits
$stmt = $pdo->query("SELECT crypto_deposits.id, crypto_deposits.crypto_type, crypto_deposits.amount, 
                            crypto_deposits.wallet_address, crypto_deposits.proof_image, 
                            crypto_deposits.created_at, crypticusers.first_name, crypticusers.last_name 
                     FROM crypto_deposits 
                     JOIN crypticusers ON crypto_deposits.user_id = crypticusers.id
                     WHERE crypto_deposits.status = 'pending'");
$pendingDeposits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Deposits Dashboard</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>

    <h2>Deposits Appproval</h2>
    <h3>Pending Crypto Deposits</h3>

    <table border="1">
        <tr>
            <th>User</th>
            <th>Crypto</th>
            <th>Amount</th>
            <th>Wallet Address</th>
            <th>Proof of Deposit</th>
            <th>Request Date</th>
            <th>Action</th>
        </tr>
        <?php foreach ($pendingDeposits as $deposit) : ?>
        <tr>
            <td><?= htmlspecialchars($deposit["first_name"] . " " . $deposit["last_name"]); ?></td>
            <td><?= htmlspecialchars($deposit["crypto_type"]); ?></td>
            <td><?= number_format($deposit["amount"], 8); ?></td>
            <td><?= htmlspecialchars($deposit["wallet_address"]); ?></td>
            <td>
                <a href="../<?= $deposit['proof_image']; ?>" target="_blank">
                    <img src="../<?= $deposit['proof_image']; ?>" width="50" height="50">
                </a>
            </td>
            <td><?= $deposit["created_at"]; ?></td>
            <td>
                <a href="approve_route.php?id=<?= $deposit['id']; ?>&action=approve&type=deposit">Approve</a> | 
                <a href="#" onclick="showRejectionModal(<?= $deposit['id']; ?>)">Reject</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <!-- Rejection Modal -->
    <div id="rejectionModal" style="display: none;">
        <form id="rejectionForm" action="approve_route.php" method="POST">
            <input type="hidden" name="id" id="deposit_id">
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="type" value="deposit">
            <label for="rejection_reason">Reason for Rejection:</label>
            <textarea name="rejection_reason" id="rejection_reason" required></textarea>
            <button type="submit">Submit</button>
            <button type="button" onclick="hideRejectionModal()">Cancel</button>
        </form>
    </div>

    <script>
    function showRejectionModal(id) {
        document.getElementById('deposit_id').value = id;
        document.getElementById('rejectionModal').style.display = 'block';
    }

    function hideRejectionModal() {
        document.getElementById('rejectionModal').style.display = 'none';
    }
    </script>

</body>
</html>
