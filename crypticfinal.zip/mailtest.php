<?php
$to = "ktlmarketingng@gmail.com";
$subject = "Test Email from PHP";
$message = "This is a test email.";
$headers = "From: info@donatewater.ng\r\n";

if (mail($to, $subject, $message, $headers)) {
    echo "✅ Email Sent Successfully!";
} else {
    echo "❌ Email Sending Failed!";
}
?>
