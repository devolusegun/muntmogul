<?php 
require 'load_env.php';
echo "<pre>";
print_r($_ENV);
echo "</pre>";

?>