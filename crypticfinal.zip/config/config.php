<?php

$host = "localhost";
$db_name = "cryptic_db";
$username = "monkey";
$password = "Loons123";

//$host = "localhost";
//$db_name = "evenspir_cryptic_db";
//$username = "evenspir_monkey";
//$password = "L00ns123@";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

session_set_cookie_params([
    'lifetime' => 86400, // 1 day
    'path' => '/',
    'domain' => '.7evenspirits.us', // Use your domain
    'secure' => false, // Set to true if using HTTPS
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();

?>
